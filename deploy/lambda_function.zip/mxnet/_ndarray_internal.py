"""NDArray namespace used to register internal functions."""
