"""Symbol namespace used to register internal functions."""
